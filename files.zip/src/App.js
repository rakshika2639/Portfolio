import React, { useState } from 'react';
import GlobalStyle from './GlobalStyle';
import Hero from './components/Hero';
import About from './components/About';
import Projects from './components/Projects';
import ProjectModal from './components/ProjectModal';
import Contact from './components/Contact';

function App() {
  const [selectedProject, setSelectedProject] = useState(null);

  return (
    <>
      <GlobalStyle />
      <Hero />
      <About />
      <Projects onProjectClick={setSelectedProject} />
      <Contact />
      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />
    </>
  );
}

export default App;
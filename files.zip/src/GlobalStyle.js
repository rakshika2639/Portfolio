import { createGlobalStyle } from 'styled-components';

const GlobalStyle = createGlobalStyle`
  body {
    margin: 0;
    font-family: 'Montserrat', 'Segoe UI', Arial, sans-serif;
    background: linear-gradient(135deg, #0f2027, #2c5364);
    color: #f4f4f4;
    min-height: 100vh;
    transition: background 0.4s ease;
  }
  * {
    box-sizing: border-box;
  }
  a {
    color: #64ffda;
    text-decoration: none;
    &:hover {
      text-decoration: underline;
    }
  }
`;

export default GlobalStyle;
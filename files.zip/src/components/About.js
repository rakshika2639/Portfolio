import React from 'react';
import styled from 'styled-components';

const Section = styled.section`
  max-width: 900px;
  margin: 2rem auto;
  padding: 2rem;
  background: rgba(44,83,100,0.85);
  border-radius: 20px;
  box-shadow: 0 2px 16px rgba(0,0,0,0.1);
`;

const Title = styled.h2`
  font-size: 2.5rem;
  margin-bottom: 1rem;
  color: #64ffda;
`;

const Text = styled.p`
  font-size: 1.2rem;
`;

export default function About() {
  return (
    <Section id="about">
      <Title>About Me</Title>
      <Text>
        Hi, I'm Rakshika—a developer passionate about designing and building impactful digital experiences. 
        My approach blends creativity with technical expertise, resulting in unique solutions for complex problems. 
        I specialize in modern web technologies and am always exploring new ways to push boundaries.
      </Text>
    </Section>
  );
}
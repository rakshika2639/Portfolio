import React, { useState } from 'react';
import styled from 'styled-components';

const Section = styled.section`
  max-width: 700px;
  margin: 3rem auto;
  padding: 2rem;
  background: rgba(44,83,100,0.85);
  border-radius: 16px;
`;

const Title = styled.h2`
  color: #64ffda;
  font-size: 2.5rem;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Input = styled.input`
  margin-bottom: 1rem;
  padding: .7rem 1rem;
  border-radius: 5px;
  border: none;
  font-size: 1rem;
`;

const TextArea = styled.textarea`
  margin-bottom: 1rem;
  padding: .7rem 1rem;
  border-radius: 5px;
  font-size: 1rem;
  border: none;
  min-height: 120px;
`;

const Button = styled.button`
  background: #64ffda;
  color: #232526;
  border: none;
  border-radius: 6px;
  padding: .8rem 2rem;
  font-weight: bold;
  font-size: 1.1rem;
  cursor: pointer;
`;

export default function Contact() {
  const [sent, setSent] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    setSent(true);
    // Replace with actual email API integration
  }

  return (
    <Section id="contact">
      <Title>Contact</Title>
      {sent ? (
        <p>Thank you for getting in touch! I'll reply soon.</p>
      ) : (
        <Form onSubmit={handleSubmit}>
          <Input type="text" name="name" placeholder="Your Name" required />
          <Input type="email" name="email" placeholder="Your Email" required />
          <TextArea name="message" placeholder="Your Message" required />
          <Button type="submit">Send</Button>
        </Form>
      )}
    </Section>
  );
}
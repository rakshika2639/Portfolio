import React from 'react';
import styled, { keyframes } from 'styled-components';

const gradientMove = keyframes`
  0% {background-position:0% 50%;}
  50% {background-position:100% 50%;}
  100% {background-position:0% 50%;}
`;

const HeroSection = styled.section`
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
  background-size: 400% 400%;
  animation: ${gradientMove} 15s ease infinite;
`;

const Name = styled.h1`
  font-size: 4rem;
  letter-spacing: .05em;
  text-shadow: 0 4px 32px rgba(0,0,0,0.4);
`;

const Tagline = styled.p`
  font-size: 1.5rem;
  margin-top: 1rem;
  font-weight: 500;
`;

export default function Hero() {
  return (
    <HeroSection>
      <Name>Rakshika</Name>
      <Tagline>Creative Developer | Building Unique Digital Experiences</Tagline>
    </HeroSection>
  );
}
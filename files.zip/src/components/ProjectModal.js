import React from 'react';
import styled from 'styled-components';

const Overlay = styled.div`
  display: ${({ show }) => (show ? 'flex' : 'none')};
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(34,49,63,0.9);
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const Modal = styled.div`
  background: #232526;
  color: #fff;
  padding: 2.5rem;
  border-radius: 14px;
  box-shadow: 0 6px 32px rgba(44,83,100,0.26);
  max-width: 500px;
`;

const CloseBtn = styled.button`
  background: #64ffda;
  color: #232526;
  border: none;
  border-radius: 6px;
  padding: .5rem 1.2rem;
  font-weight: bold;
  font-size: 1rem;
  margin-top: 2rem;
  cursor: pointer;
`;

export default function ProjectModal({ project, onClose }) {
  return (
    <Overlay show={!!project}>
      {project && (
        <Modal>
          <h2>{project.title}</h2>
          <p>{project.details}</p>
          <CloseBtn onClick={onClose}>Close</CloseBtn>
        </Modal>
      )}
    </Overlay>
  );
}
import React from 'react';
import styled from 'styled-components';

const Section = styled.section`
  max-width: 1000px;
  margin: 2rem auto;
  padding: 2rem;
`;

const Title = styled.h2`
  color: #64ffda;
  font-size: 2.5rem;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
`;

const Card = styled.div`
  background: rgba(34, 193, 195, 0.12);
  border-radius: 18px;
  box-shadow: 0 2px 12px rgba(44,83,100,.18);
  padding: 1.5rem;
  cursor: pointer;
  transition: transform .2s;
  &:hover { transform: translateY(-6px) scale(1.03); }
`;

const projects = [
  {
    title: "Interactive Art Gallery",
    desc: "A virtual gallery with immersive transitions and generative art.",
    details: "Built with Three.js, React, and WebGL custom shaders. Features real-time art generation and multi-user viewing.",
  },
  {
    title: "AI-Powered Portfolio Generator",
    desc: "Create stunning portfolios with AI-driven content and layouts.",
    details: "Utilizes GPT-4 for copywriting and custom design suggestions. Fully responsive and exportable.",
  },
  {
    title: "Unique Blog Platform",
    desc: "A blog engine with customizable post formats and animated backgrounds.",
    details: "Built using Next.js, MDX, and styled-components. Supports media-rich posts and advanced SEO.",
  }
];

export default function Projects({ onProjectClick }) {
  return (
    <Section id="projects">
      <Title>Projects</Title>
      <Grid>
        {projects.map((project, i) => (
          <Card key={i} onClick={() => onProjectClick(project)}>
            <h3>{project.title}</h3>
            <p>{project.desc}</p>
          </Card>
        ))}
      </Grid>
    </Section>
  );
}